module.exports = {
    testEnvironment: './puppeteer_environment.js',
};
